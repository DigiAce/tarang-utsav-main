/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        lightYellow: "#f6d876",
        white2: "#fffbf2",
        darkGreen: "#05ab54",
        dark: "#1e1e1e",
        navBarColor: "#fffcf9",
      },
      fontFamily: {
        Poppins: ["Poppins", "sans-serif"],
        leagueGothic: ["League Gothic", "sans-serif"],
      },
      container: {
        center: true,
        padding: {
          DEFAULT: "1rem",
          sm: "2rem",
          md: "0",
          lg: "4rem",
          xl: "5rem",
          "2xl": "6rem",
        },
      },
      backgroundImage: {
        'gradient-navbar': 'linear-gradient(90deg, rgba(221,218,218,0.47942927170868344) 35%, rgba(221,218,218,0.48503151260504207) 35%);',
      },
    },
  },
  plugins: [],
};
