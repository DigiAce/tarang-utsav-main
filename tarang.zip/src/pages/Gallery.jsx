import React from "react";

const Gallery = () => {
  return <div>gallery</div>;
};

export default Gallery;
