import React from "react";

const ValueCard = () => {
  return (
    <div className="flex flex-col md:flex-row items-center justify-center gap-4 p-20 bg-[#f5f0eb]">
      {/* Podcast */}
      <div className="flex items-center justify-center w-full md:w-1/3 h-32 bg-[#dde1d6] rounded-l-full">
        <p className="text-center text-sm font-medium">
          Listen to the <br />
          <span className="font-bold">PODCAST</span>
        </p>
      </div>

      {/* Services */}
      <div className="flex items-center justify-center w-full md:w-1/3 h-32 bg-[#d8cdc0] rounded-none">
        <p className="text-center text-sm font-medium">
          View The <br />
          <span className="font-bold">Services</span>
        </p>
      </div>

      {/* Journal */}
      <div className="flex items-center justify-center w-full md:w-1/3 h-32 bg-[#eadad3] rounded-r-full">
        <p className="text-center text-sm font-medium">
          Read The <br />
          <span className="font-bold">Journal</span>
        </p>
      </div>
    </div>
  );
};

export default ValueCard;
